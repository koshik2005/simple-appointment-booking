/*
  # Initial Schema for Doctor Appointment System

  1. New Tables
    - `profiles` - User profiles for both patients and doctors
      - `id` (uuid, primary key) - Links to auth.users
      - `full_name` (text)
      - `role` (text) - 'patient', 'doctor', or 'admin'
      - `specialty` (text, for doctors)
      - `bio` (text)
      - `is_active` (boolean)
    
    - `appointments`
      - `id` (uuid, primary key)
      - `patient_id` (uuid) - References profiles
      - `doctor_id` (uuid) - References profiles
      - `date_time` (timestamptz)
      - `status` (text) - 'pending', 'confirmed', 'cancelled'
      - `reason` (text)
      
    - `doctor_schedules`
      - `id` (uuid, primary key)
      - `doctor_id` (uuid) - References profiles
      - `day_of_week` (integer)
      - `start_time` (time)
      - `end_time` (time)
      
  2. Security
    - Enable RLS on all tables
    - Policies for profile access
    - Policies for appointment management
    - Policies for schedule management
*/

-- Create profiles table
CREATE TABLE profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id),
  full_name text NOT NULL,
  role text NOT NULL CHECK (role IN ('patient', 'doctor', 'admin')),
  specialty text,
  bio text,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create appointments table
CREATE TABLE appointments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id uuid REFERENCES profiles(id),
  doctor_id uuid REFERENCES profiles(id),
  date_time timestamptz NOT NULL,
  status text NOT NULL CHECK (status IN ('pending', 'confirmed', 'cancelled')),
  reason text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create doctor schedules table
CREATE TABLE doctor_schedules (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  doctor_id uuid REFERENCES profiles(id),
  day_of_week integer CHECK (day_of_week BETWEEN 0 AND 6),
  start_time time NOT NULL,
  end_time time NOT NULL,
  created_at timestamptz DEFAULT now(),
  CONSTRAINT valid_time_range CHECK (start_time < end_time)
);

-- Enable RLS
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE appointments ENABLE ROW LEVEL SECURITY;
ALTER TABLE doctor_schedules ENABLE ROW LEVEL SECURITY;

-- Profiles policies
CREATE POLICY "Public profiles are viewable by everyone"
  ON profiles FOR SELECT
  USING (true);

CREATE POLICY "Users can update own profile"
  ON profiles FOR UPDATE
  USING (auth.uid() = id);

-- Appointments policies
CREATE POLICY "Users can view their own appointments"
  ON appointments FOR SELECT
  USING (
    auth.uid() = patient_id OR 
    auth.uid() = doctor_id OR 
    EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin')
  );

CREATE POLICY "Patients can create appointments"
  ON appointments FOR INSERT
  WITH CHECK (
    auth.uid() = patient_id AND
    EXISTS (SELECT 1 FROM profiles WHERE id = doctor_id AND role = 'doctor' AND is_active = true)
  );

-- Doctor schedules policies
CREATE POLICY "Doctor schedules are viewable by everyone"
  ON doctor_schedules FOR SELECT
  USING (true);

CREATE POLICY "Doctors can manage their schedules"
  ON doctor_schedules FOR ALL
  USING (
    EXISTS (
      SELECT 1 FROM profiles 
      WHERE id = auth.uid() 
      AND (role = 'doctor' OR role = 'admin')
    )
  );

-- Functions
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS trigger AS $$
BEGIN
  INSERT INTO profiles (id, full_name, role)
  VALUES (new.id, new.raw_user_meta_data->>'full_name', 'patient');
  RETURN new;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger for new user creation
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();