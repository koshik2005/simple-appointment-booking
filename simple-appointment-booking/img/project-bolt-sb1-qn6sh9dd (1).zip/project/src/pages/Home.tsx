import React from 'react';
import { Link } from 'react-router-dom';
import { Calendar, Clock, Users, Shield } from 'lucide-react';

function Home() {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <div className="relative bg-gradient-to-r from-blue-600 to-blue-800 text-white py-24">
        <div className="container mx-auto px-6">
          <div className="max-w-3xl">
            <h1 className="text-5xl font-bold mb-6">
              Your Health, Your Schedule
            </h1>
            <p className="text-xl mb-8">
              Book appointments with trusted healthcare professionals in minutes.
              Quality care at your convenience.
            </p>
            <Link
              to="/register"
              className="bg-white text-blue-600 px-8 py-3 rounded-lg font-semibold hover:bg-blue-50 transition-colors"
            >
              Get Started
            </Link>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="py-24 bg-white">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl font-bold text-center mb-16">
            Why Choose Our Platform?
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-12">
            <FeatureCard
              icon={<Calendar className="w-8 h-8" />}
              title="Easy Scheduling"
              description="Book appointments 24/7 with just a few clicks"
            />
            <FeatureCard
              icon={<Clock className="w-8 h-8" />}
              title="Real-time Availability"
              description="See doctor's availability instantly and choose your preferred time"
            />
            <FeatureCard
              icon={<Users className="w-8 h-8" />}
              title="Expert Doctors"
              description="Access to verified and experienced healthcare professionals"
            />
            <FeatureCard
              icon={<Shield className="w-8 h-8" />}
              title="Secure Platform"
              description="Your data is protected with enterprise-grade security"
            />
          </div>
        </div>
      </div>
    </div>
  );
}

function FeatureCard({ icon, title, description }: {
  icon: React.ReactNode;
  title: string;
  description: string;
}) {
  return (
    <div className="text-center p-6 rounded-lg bg-gray-50">
      <div className="inline-block p-3 bg-blue-100 rounded-lg text-blue-600 mb-4">
        {icon}
      </div>
      <h3 className="text-xl font-semibold mb-2">{title}</h3>
      <p className="text-gray-600">{description}</p>
    </div>
  );
}

export default Home;