import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

function Dashboard() {
  const { profile, loading } = useAuth();

  if (loading) {
    return <div>Loading...</div>;
  }

  if (!profile) {
    return <Navigate to="/login" />;
  }

  return (
    <div className="min-h-screen bg-gray-50 pt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-3xl font-bold text-gray-900">Welcome, {profile.full_name}</h1>
        <div className="mt-6">
          {profile.role === 'patient' && (
            <div>
              <h2 className="text-xl font-semibold text-gray-800">Your Appointments</h2>
              {/* Appointment list will go here */}
            </div>
          )}
          {profile.role === 'doctor' && (
            <div>
              <h2 className="text-xl font-semibold text-gray-800">Your Schedule</h2>
              {/* Doctor schedule will go here */}
            </div>
          )}
          {profile.role === 'admin' && (
            <div>
              <h2 className="text-xl font-semibold text-gray-800">Admin Dashboard</h2>
              {/* Admin controls will go here */}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default Dashboard;