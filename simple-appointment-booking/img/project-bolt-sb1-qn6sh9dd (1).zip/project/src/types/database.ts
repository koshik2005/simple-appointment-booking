export interface Profile {
  id: string;
  full_name: string;
  role: 'patient' | 'doctor' | 'admin';
  specialty?: string;
  bio?: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface Appointment {
  id: string;
  patient_id: string;
  doctor_id: string;
  date_time: string;
  status: 'pending' | 'confirmed' | 'cancelled';
  reason: string;
  created_at: string;
  updated_at: string;
}

export interface DoctorSchedule {
  id: string;
  doctor_id: string;
  day_of_week: number;
  start_time: string;
  end_time: string;
  created_at: string;
}